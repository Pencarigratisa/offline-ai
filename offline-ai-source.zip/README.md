# Offline AI — GGUF / Qwen Edition

Versi ini mengubah engine dari MediaPipe LLM Inference menjadi **llama.cpp Android AAR**, sehingga aplikasi dapat memuat model **GGUF** seperti `qwen2.5-1.5b-instruct-q8_0.gguf` langsung di perangkat.

## Build

GitHub Actions menjalankan:

1. JDK 17
2. Gradle 8.2.1
3. `gradle --no-daemon assembleDebug`
4. APK debug diunggah sebagai artifact `offline-ai-apk`

## Model

Aplikasi sekarang menerima `.gguf`. Model tidak dibundel ke APK. Setelah APK terpasang:

1. Buka Settings → Manage Models.
2. Tekan tombol upload.
3. Pilih file `.gguf`.
4. Tekan **Load to RAM**.
5. Kembali ke chat dan kirim pesan.

Model `Qwen2.5-1.5B-Instruct` Q8_0 sekitar 1,76 GB seperti yang dipilih pengguna adalah model GGUF yang ditujukan untuk chat/instruct.

## Engine

Dependency utama:

`dev.ffmpegkit-maintained:llama-android:0.1.1`

Library tersebut adalah AAR llama.cpp untuk Android dan mendukung GGUF pada ABI `arm64-v8a`. Versi gratis yang dipakai di project ini melakukan chat completion secara non-streaming; jadi jawaban muncul setelah inference selesai, bukan token demi token.

## Offline

Setelah model dan engine ada di APK, inference berlangsung lokal di perangkat dan aplikasi tidak membutuhkan API key atau server AI. GitHub Actions tetap membutuhkan internet saat proses build untuk mengambil dependency Gradle.

## Catatan perangkat

Target utama project ini adalah perangkat Android arm64 seperti Infinix Note 30 Pro pengguna. Konfigurasi engine memakai context 4096 dan 4 CPU threads sebagai titik awal. Jika model terlalu berat atau Android membunuh proses karena tekanan RAM, turunkan context atau gunakan model GGUF yang lebih kecil.

## Jika Build Gagal

Jangan langsung mengubah banyak file. Kirim bagian log mulai dari:

`> Task :app:compileDebugKotlin FAILED`

atau task native/library yang gagal. Kita perbaiki berdasarkan error yang sebenarnya.
