# Offline AI - GGUF / Qwen build

This version uses `dev.ffmpegkit-maintained:llama-android:0.1.1` and loads GGUF models directly with llama.cpp.

## Build with GitHub Actions

1. Upload the contents of this project to the root of a GitHub repository.
2. Commit to `main`.
3. Open **Actions** and run **Android CI**.
4. Download the `offline-ai-apk` artifact after the build succeeds.

## Model

The app expects a `.gguf` model. For the model discussed in this project, use the Qwen2.5 1.5B Instruct Q8_0 GGUF file.

Import it from **Settings → Manage Models → Import**, then press **Load**.

The model is not bundled into the APK, so the APK remains relatively small. Inference is local on the device once the model is loaded.

## Important

The free `llama-android` 0.1.1 API provides non-streaming chat completion. The UI therefore receives the completed answer at once rather than token-by-token.
