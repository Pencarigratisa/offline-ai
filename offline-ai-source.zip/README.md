# Offline AI - Qwen GGUF

Android offline AI project using llama.cpp-compatible GGUF models.

## Build with GitHub Actions

Open **Actions → Build Offline AI APK → Run workflow**.

After a successful run, open the run summary and scroll to **Artifacts**. Download **OfflineAI-APK**. The downloaded ZIP contains `OfflineAI-debug.apk`.

The workflow explicitly verifies the APK exists before uploading it, so a missing APK will fail the run instead of silently producing an empty artifact.


## Compose crash fix (v1.1.1)
This build aligns the Compose BOM with the Kotlin/Compose compiler used by the project and removes the Material3 ProgressIndicator from the model-loading UI. The previous APK crashed with `NoSuchMethodError` in `androidx.compose.material3.ProgressIndicatorKt`, before GGUF/llama.cpp model loading was reached.
