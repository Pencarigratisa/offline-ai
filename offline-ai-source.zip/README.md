# Offline AI for Android

Aplikasi chatbot Android yang menjalankan model bahasa lokal di perangkat. Core chat tidak menggunakan API AI online dan manifest aplikasi tidak meminta permission INTERNET.

## Yang sudah disiapkan

- Jetpack Compose + Material 3
- Room untuk riwayat chat
- MediaPipe Tasks GenAI 0.10.14 untuk local inference
- Model Manager untuk import `.bin` / `.task`
- Dark mode mengikuti tema sistem
- GitHub Actions untuk menghasilkan APK debug
- Tidak ada API key atau backend AI online

## Penting tentang "offline"

Aplikasi dapat melakukan inference tanpa Wi-Fi/data seluler setelah model lokal tersedia. Proses build GitHub tetap membutuhkan internet karena Gradle harus mengunduh dependency.

## Struktur

```text
offline-ai/
├── .github/workflows/build.yml
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/...
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Build lewat GitHub — cara yang paling mudah

1. Buat repository GitHub baru, misalnya `offline-ai`.
2. Upload **isi folder project ini**, bukan file `.zip` sebagai satu file di dalam repository.
3. Pastikan folder `.github/workflows/build.yml` ikut ter-upload.
4. Commit ke branch `main`.
5. Buka tab **Actions**.
6. Pilih workflow **Android CI**.
7. Tunggu sampai job `Build Debug APK` selesai.
8. Buka run yang selesai.
9. Pada bagian **Artifacts**, download `offline-ai-apk`.
10. Di dalam artifact terdapat `app-debug.apk`.

Workflow sengaja menggunakan Gradle 8.2.1 secara langsung sehingga repository tidak membutuhkan `gradlew` / `gradle-wrapper.jar`.

## Model AI

Aplikasi tidak memasukkan file model besar ke APK. Import model dilakukan dari dalam aplikasi melalui tombol **Import Model**. Model harus merupakan model yang kompatibel dengan MediaPipe LLM Inference API.

Gunakan model yang sesuai dengan runtime MediaPipe yang dipakai dan kemampuan perangkat. Model yang terlalu besar dapat menyebabkan loading lambat atau Out of Memory.

## Cara menggunakan

1. Install APK.
2. Buka Offline AI.
3. Tekan ikon Settings.
4. Import file model `.bin` atau `.task` yang kompatibel.
5. Tekan **Load to RAM**.
6. Kembali ke chat.
7. Kirim pertanyaan.
8. Setelah model berhasil dimuat, matikan Wi-Fi/data untuk menguji mode offline.

## Jika build gagal

### 1. `SDK location not found`

Untuk GitHub Actions seharusnya tidak terjadi karena runner menyiapkan Java dan Gradle. Jika membangun lokal, buka project melalui Android Studio dan biarkan SDK yang diperlukan dipasang.

### 2. `Could not find com.google.mediapipe:tasks-genai`

Pastikan repository `google()` dan `mavenCentral()` ada di `settings.gradle.kts`, lalu jalankan build ulang.

### 3. Error Kotlin / Compose

Jangan mengganti versi Kotlin, Compose compiler, dan AGP secara acak. Project ini sengaja menggunakan Kotlin 1.9.22 + Compose compiler 1.5.8 + AGP 8.2.2.

### 4. APK berhasil dibuat tetapi model gagal dimuat

Ini biasanya bukan error Gradle. Periksa apakah model memang kompatibel dengan MediaPipe LLM Inference API, file tidak rusak, dan RAM perangkat mencukupi.

### 5. `Out of Memory`

Coba model yang lebih kecil/lebih terkuantisasi. Model AI tidak sama dengan APK; ukuran model sangat memengaruhi RAM ketika dimuat.

### 6. AI tidak menjawab setelah internet dimatikan

Pastikan model sudah berhasil di-import dan **Load to RAM** sebelum mematikan koneksi. Core inference aplikasi ini tidak membutuhkan API internet.

## Catatan teknis

MediaPipe Tasks GenAI 0.10.14 adalah API eksperimental/legacy untuk on-device LLM dan API ini telah berkembang. Jika nanti ingin pindah ke runtime on-device yang lebih baru, buat migration sebagai perubahan terpisah agar build yang sekarang tetap stabil.
