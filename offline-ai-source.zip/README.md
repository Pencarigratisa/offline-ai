# Offline AI - Qwen GGUF

Android offline AI project using llama.cpp-compatible GGUF models.

## Build with GitHub Actions

Open **Actions → Build Offline AI APK → Run workflow**.

After a successful run, open the run summary and scroll to **Artifacts**. Download **OfflineAI-APK**. The downloaded ZIP contains `OfflineAI-debug.apk`.

The workflow explicitly verifies the APK exists before uploading it, so a missing APK will fail the run instead of silently producing an empty artifact.


## Compose crash fix (v1.1.1)
This build aligns the Compose BOM with the Kotlin/Compose compiler used by the project and removes the Material3 ProgressIndicator from the model-loading UI. The previous APK crashed with `NoSuchMethodError` in `androidx.compose.material3.ProgressIndicatorKt`, before GGUF/llama.cpp model loading was reached.

## Chat prompt fix
The GGUF engine uses the AAR chat-completion API with its automatic chat template. The app no longer sends artificial `System:`/`Model:` completion markers, which can confuse instruction-tuned models such as Qwen. Conversation history is passed as contextual text and the current user message remains the final prompt.

## v1.2 Smart Offline

Peningkatan:
- Prompt sistem lebih kuat untuk matematika, sains, pertanyaan bertahap, dan analisis dokumen.
- Context window dinaikkan ke 4096 dan output maksimum ke 512 token.
- Lampiran gambar dengan OCR offline (ML Kit bundled).
- Lampiran PDF: hingga 8 halaman pertama dirender dan dibaca dengan OCR offline.
- Kamera: foto langsung dapat dianalisis melalui OCR.
- Lampiran diproses di perangkat; teks hasil OCR diteruskan ke model GGUF lokal.

Catatan: fitur gambar pada versi ini adalah **OCR**, bukan vision AI. Jadi AI dapat membaca teks pada foto/dokumen, tetapi belum memahami objek/gambar non-teks seperti manusia, diagram tanpa teks, atau pemandangan. Vision multimodal membutuhkan model GGUF multimodal + projector khusus dan sengaja tidak dimasukkan pada versi ini agar stabil di perangkat kelas menengah.

Untuk kualitas jawaban yang lebih baik, gunakan Qwen2.5-Instruct dengan quantization Q4_K_M jika RAM dan penyimpanan mencukupi. Model Q2_K tetap didukung untuk penggunaan yang lebih ringan.

## v1.3 Online Learn + Offline Knowledge

Versi ini menambahkan dua mode:

- **Mode Online**: ketika internet tersedia, aplikasi dapat mengambil materi pendidikan dari Wikipedia Indonesia, menyimpannya ke database lokal, lalu memasukkan materi tersebut sebagai konteks untuk model GGUF lokal.
- **Mode Offline**: tidak melakukan permintaan internet. Chat menggunakan model GGUF dan pengetahuan yang sebelumnya sudah disimpan lewat fitur Belajar.
- **Belajar dari Internet**: buka ikon sekolah di bagian atas chat, masukkan topik, lalu pilih "Pelajari & simpan".

Catatan penting: fitur ini adalah **retrieval + local knowledge cache**, bukan fine-tuning/retraining bobot Qwen. Fine-tuning langsung di HP akan jauh lebih berat dan tidak diperlukan untuk tujuan belajar mandiri.

Sumber online v1.3 saat ini difokuskan ke Wikipedia Indonesia agar implementasi tetap sederhana dan stabil tanpa API key.


## v1.4 — 3 Mode + Multi-source Web Search

- **Online**: melakukan Web Search saat ada internet, mengambil beberapa sumber publik, dan menyimpan teks yang berhasil dibaca ke Knowledge Base lokal.
- **Offline**: tidak melakukan request web; jawaban memakai Qwen + Knowledge Base yang sudah tersimpan.
- **Belajar**: mencari dan menyimpan materi dari web, lalu membuat 5 soal latihan mandiri menggunakan model lokal.
- Sumber pencarian mencakup hasil web umum serta prioritas Wikipedia, OpenStax, dan Khan Academy bila tersedia di hasil pencarian.
- Ini adalah retrieval/knowledge caching, bukan fine-tuning bobot model.
- Database Knowledge Base dimigrasikan dari v2 ke v3.


## v1.4.1 build fixes
- Fixed Kotlin type inference in the offline Knowledge Base ranking code.
- Fixed Compose `Modifier.weight()` scope for the Online/Offline/Belajar buttons.
- Fixed Room schema version to 3 so the existing 1->2->3 migrations are actually applied.
- The SDK XML and native-strip messages shown by Gradle are warnings, not the Kotlin compilation failure.


## v1.4.2 compile fix
- Fixed explicit RowScope imports for ModeChip/ModeButton so Modifier.weight() resolves correctly.
- Rewrote offline Knowledge Base ranking without ambiguous Kotlin generic inference.
- Version code 9 / version name 1.4.2-compile-fix.


## v1.4.3 fix

Added `@OptIn(ExperimentalMaterial3Api::class)` to LearnScreen because the Compose BOM used by this project marks TopAppBar as experimental and the GitHub build treats that warning as a compilation failure.
