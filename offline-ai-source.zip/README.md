# Offline AI - Qwen GGUF

Android offline AI project using llama.cpp-compatible GGUF models.

## Build with GitHub Actions

Open **Actions → Build Offline AI APK → Run workflow**.

After a successful run, open the run summary and scroll to **Artifacts**. Download **OfflineAI-APK**. The downloaded ZIP contains `OfflineAI-debug.apk`.

The workflow explicitly verifies the APK exists before uploading it, so a missing APK will fail the run instead of silently producing an empty artifact.


## Compose crash fix (v1.1.1)
This build aligns the Compose BOM with the Kotlin/Compose compiler used by the project and removes the Material3 ProgressIndicator from the model-loading UI. The previous APK crashed with `NoSuchMethodError` in `androidx.compose.material3.ProgressIndicatorKt`, before GGUF/llama.cpp model loading was reached.

## Chat prompt fix
The GGUF engine uses the AAR chat-completion API with its automatic chat template. The app no longer sends artificial `System:`/`Model:` completion markers, which can confuse instruction-tuned models such as Qwen. Conversation history is passed as contextual text and the current user message remains the final prompt.

## v1.2 Smart Offline

Peningkatan:
- Prompt sistem lebih kuat untuk matematika, sains, pertanyaan bertahap, dan analisis dokumen.
- Context window dinaikkan ke 4096 dan output maksimum ke 512 token.
- Lampiran gambar dengan OCR offline (ML Kit bundled).
- Lampiran PDF: hingga 8 halaman pertama dirender dan dibaca dengan OCR offline.
- Kamera: foto langsung dapat dianalisis melalui OCR.
- Lampiran diproses di perangkat; teks hasil OCR diteruskan ke model GGUF lokal.

Catatan: fitur gambar pada versi ini adalah **OCR**, bukan vision AI. Jadi AI dapat membaca teks pada foto/dokumen, tetapi belum memahami objek/gambar non-teks seperti manusia, diagram tanpa teks, atau pemandangan. Vision multimodal membutuhkan model GGUF multimodal + projector khusus dan sengaja tidak dimasukkan pada versi ini agar stabil di perangkat kelas menengah.

Untuk kualitas jawaban yang lebih baik, gunakan Qwen2.5-Instruct dengan quantization Q4_K_M jika RAM dan penyimpanan mencukupi. Model Q2_K tetap didukung untuk penggunaan yang lebih ringan.
