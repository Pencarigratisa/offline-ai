# Offline AI - GGUF / Qwen build

This version uses `dev.ffmpegkit-maintained:llama-android:0.1.1` and loads GGUF models directly with llama.cpp.

## Build with GitHub Actions

1. Upload the contents of this project to the root of a GitHub repository.
2. Commit to `main`.
3. Open **Actions** and run **Android CI**.
4. Download the `offline-ai-apk` artifact after the build succeeds.

## Model

The app expects a `.gguf` model. For the model discussed in this project, use a Qwen2.5 Instruct GGUF model. For this phone, the recommended starting point is Qwen2.5 0.5B Instruct Q4_K_M (~491 MB from the official Qwen GGUF repository). The app also accepts larger GGUF files, but larger models use more RAM.

Import it from **Settings → Manage Models → Import**, then press **Load**.

The model is not bundled into the APK, so the APK remains relatively small. Inference is local on the device once the model is loaded.

## Important

The free `llama-android` 0.1.1 API provides non-streaming chat completion. The UI therefore receives the completed answer at once rather than token-by-token.

## Recommended lightweight model

For a phone with 8 GB RAM, start with **Qwen2.5-0.5B-Instruct Q4_K_M**. The official Qwen GGUF repository lists this quantization at about 491 MB. The app uses a 2048-token context by default to keep peak memory lower.

The engine accepts GGUF models supported by the bundled llama.cpp AAR. The AAR documents Qwen2.5 0.5B as a supported lightweight model and uses arm64-v8a CPU/NEON.
