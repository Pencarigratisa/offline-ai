# Offline AI currently keeps release shrinking disabled for maximum build reliability.
# Keep this file present because app/build.gradle.kts references it.
