package com.offlineai.app.domain

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ModelManager(private val context: Context) {
    private val modelsDir = File(context.filesDir, "models").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("offline_ai_prefs", Context.MODE_PRIVATE)

    fun getLocalModels(): List<File> =
        modelsDir.listFiles()
            ?.filter { it.isFile && (it.extension.equals("bin", true) || it.extension.equals("task", true)) }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun getActiveModel(): File? =
        prefs.getString("active_model_path", null)
            ?.let(::File)
            ?.takeIf { it.exists() && it.isFile }

    fun setActiveModel(file: File) {
        prefs.edit().putString("active_model_path", file.absolutePath).apply()
    }

    fun deleteModel(file: File) {
        if (getActiveModel()?.absolutePath == file.absolutePath) {
            prefs.edit().remove("active_model_path").apply()
        }
        file.delete()
    }

    suspend fun importModelFromUri(
        uri: Uri,
        progressCallback: (Int) -> Unit
    ): File? = withContext(Dispatchers.IO) {
        try {
            val displayName = queryDisplayName(uri) ?: "imported_model_${System.currentTimeMillis()}.bin"
            val safeName = File(displayName).name
            val extension = safeName.substringAfterLast('.', "").lowercase()
            if (extension != "bin" && extension != "task") return@withContext null

            val destinationFile = uniqueDestination(File(modelsDir, safeName))
            val totalSize = context.contentResolver.openFileDescriptor(uri, "r")?.use {
                it.statSize.takeIf { size -> size > 0L }
            } ?: -1L

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var copied = 0L
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        copied += read
                        if (totalSize > 0L) {
                            progressCallback(((copied * 100L) / totalSize).coerceIn(0L, 100L).toInt())
                        }
                    }
                    output.flush()
                }
            } ?: return@withContext null

            progressCallback(100)
            destinationFile
        } catch (_: Exception) {
            null
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) else null
            } else null
        }
    }

    private fun uniqueDestination(original: File): File {
        if (!original.exists()) return original
        val base = original.nameWithoutExtension
        val extension = original.extension
        var counter = 2
        var candidate: File
        do {
            candidate = File(modelsDir, "$base ($counter).$extension")
            counter++
        } while (candidate.exists())
        return candidate
    }
}
