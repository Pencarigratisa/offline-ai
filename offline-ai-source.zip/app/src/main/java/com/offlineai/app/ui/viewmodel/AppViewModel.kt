package com.offlineai.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.offlineai.app.OfflineAiApp
import com.offlineai.app.data.ConversationEntity
import com.offlineai.app.data.MessageEntity
import com.offlineai.app.domain.AttachmentProcessor
import com.offlineai.app.domain.AttachmentResult
import com.offlineai.app.domain.MediaPipeEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as OfflineAiApp
    private val db = app.database.chatDao()
    val modelManager = app.modelManager
    val aiEngine = MediaPipeEngine(app)
    private val attachmentProcessor = AttachmentProcessor(app)

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState

    private val _currentConversationId = MutableStateFlow<Long?>(null)
    val currentConversationId: StateFlow<Long?> = _currentConversationId

    private val _messages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messages

    private val _conversations = MutableStateFlow<List<ConversationEntity>>(emptyList())
    val conversations: StateFlow<List<ConversationEntity>> = _conversations

    private val _localModels = MutableStateFlow<List<File>>(emptyList())
    val localModels: StateFlow<List<File>> = _localModels

    private val _activeModel = MutableStateFlow<File?>(null)
    val activeModel: StateFlow<File?> = _activeModel

    private val _engineLoaded = MutableStateFlow(false)
    val engineLoaded: StateFlow<Boolean> = _engineLoaded

    private val _attachment = MutableStateFlow<AttachmentState>(AttachmentState.None)
    val attachment: StateFlow<AttachmentState> = _attachment

    init {
        observeConversations()
        refreshModels()
    }

    private fun observeConversations() {
        viewModelScope.launch(Dispatchers.IO) {
            db.getAllConversations().collect {
                _conversations.value = it
            }
        }
    }

    fun refreshModels() {
        _localModels.value = modelManager.getLocalModels()
        _activeModel.value = modelManager.getActiveModel()
        _engineLoaded.value = aiEngine.isLoaded()
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            _uiState.value = UiState.Importing(0)
            val file = modelManager.importModelFromUri(uri) { progress ->
                _uiState.value = UiState.Importing(progress)
            }
            if (file != null) {
                _uiState.value = UiState.Success("Model berhasil diimpor: ${file.name}")
                refreshModels()
            } else {
                _uiState.value = UiState.Error("Gagal mengimpor model. Pastikan file .gguf yang dipilih valid dan kompatibel dengan llama.cpp.")
            }
        }
    }

    fun deleteModel(file: File) {
        if (_activeModel.value?.absolutePath == file.absolutePath && aiEngine.isLoaded()) {
            aiEngine.unloadModel()
        }
        modelManager.deleteModel(file)
        refreshModels()
    }

    fun loadModel(file: File) {
        viewModelScope.launch {
            _uiState.value = UiState.Loading("Memuat model ke RAM...")
            try {
                aiEngine.loadModel(file)
                modelManager.setActiveModel(file)
                refreshModels()
                _uiState.value = UiState.Success("Model siap digunakan secara offline.")
            } catch (e: Exception) {
                aiEngine.unloadModel()
                refreshModels()
                _uiState.value = UiState.Error("Gagal memuat model: ${e.message ?: "format model tidak didukung"}")
            }
        }
    }

    fun unloadModel() {
        aiEngine.unloadModel()
        _engineLoaded.value = false
        _uiState.value = UiState.Idle
    }

    fun startNewChat() {
        _currentConversationId.value = null
        _messages.value = emptyList()
        _uiState.value = UiState.Idle
    }

    fun loadChat(conversationId: Long) {
        _currentConversationId.value = conversationId
        viewModelScope.launch(Dispatchers.IO) {
            _messages.value = db.getMessagesForConversation(conversationId).first()
            _uiState.value = UiState.Idle
        }
    }

    fun deleteChat(conversation: ConversationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            db.deleteMessagesByConversation(conversation.id)
            db.deleteConversation(conversation)
            if (_currentConversationId.value == conversation.id) {
                startNewChat()
            }
        }
    }

    fun attachFile(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _attachment.value = AttachmentState.Processing("Membaca lampiran…")
            val result = attachmentProcessor.process(uri)
            _attachment.value = if (result.success) {
                AttachmentState.Ready(result)
            } else {
                AttachmentState.Error(result.name, result.extractedText)
            }
        }
    }

    fun clearAttachment() {
        _attachment.value = AttachmentState.None
    }

    fun sendMessage(userText: String) {
        val cleanText = userText.trim()
        val currentAttachment = (_attachment.value as? AttachmentState.Ready)?.result
        if (cleanText.isEmpty() && currentAttachment == null) return
        val messageToSave = cleanText.ifBlank { "Analisis lampiran ini." }
        if (!aiEngine.isLoaded()) {
            _uiState.value = UiState.Error("Model AI belum dimuat. Buka Settings untuk memuat model.")
            return
        }
        if (_uiState.value is UiState.Generating || _uiState.value is UiState.Streaming) return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                var convId = _currentConversationId.value
                if (convId == null) {
                    val title = messageToSave.take(40).let { if (messageToSave.length > 40) "$it…" else it }
                    convId = db.insertConversation(ConversationEntity(title = title))
                    _currentConversationId.value = convId
                }

                db.insertMessage(MessageEntity(conversationId = convId, role = "user", content = messageToSave))
                _messages.value = db.getMessagesForConversationSync(convId)

                val history = db.getMessagesForConversationSync(convId)
                val prompt = buildContextPrompt(history, currentAttachment)
                _uiState.value = UiState.Generating

                var assistantResponse = ""
                aiEngine.generateResponseAsync(prompt)
                    .catch { e ->
                        _uiState.value = UiState.Error("Inference gagal: ${e.message ?: "kesalahan tidak diketahui"}")
                    }
                    .collect { chunk ->
                        assistantResponse += chunk
                        _uiState.value = UiState.Streaming(assistantResponse)
                    }

                if (assistantResponse.isNotBlank()) {
                    db.insertMessage(MessageEntity(conversationId = convId, role = "assistant", content = assistantResponse))
                    _messages.value = db.getMessagesForConversationSync(convId)
                }

                if (_uiState.value !is UiState.Error) {
                    _attachment.value = AttachmentState.None
                    _uiState.value = UiState.Idle
                }
            } catch (e: Exception) {
                _uiState.value = UiState.Error("Gagal memproses pesan: ${e.message ?: "kesalahan tidak diketahui"}")
            }
        }
    }

    fun stopGeneration() {
        aiEngine.stopGeneration()
        _uiState.value = UiState.Idle
    }

    private fun buildContextPrompt(
        history: List<MessageEntity>,
        attachment: AttachmentResult? = null
    ): String {
        val recent = history.takeLast(8)
        val latestUser = recent.lastOrNull { it.role == "user" }?.content.orEmpty()
        val previous = recent.dropLast(1).takeLast(6)

        val sb = StringBuilder()
        if (previous.isNotEmpty()) {
            sb.append("Konteks percakapan sebelumnya:\n")
            previous.forEach { msg ->
                when (msg.role) {
                    "user" -> sb.append("Pengguna: ${msg.content.take(1800)}\n")
                    "assistant" -> sb.append("Asisten: ${msg.content.take(1800)}\n")
                }
            }
            sb.append('\n')
        }

        if (attachment != null) {
            sb.append("Lampiran yang harus dianalisis: ${attachment.name}\n")
            sb.append("Isi hasil pembacaan/OCR lampiran:\n")
            sb.append(attachment.extractedText.take(7000))
            sb.append("\n\n")
        }

        if (latestUser.isNotBlank()) {
            sb.append("Pertanyaan pengguna saat ini:\n")
            sb.append(latestUser)
        } else if (attachment != null) {
            sb.append("Tolong analisis lampiran tersebut dan jelaskan hal-hal penting yang dapat disimpulkan dari isinya.")
        }
        return sb.toString().trim()
    }

    override fun onCleared() {
        aiEngine.unloadModel()
        super.onCleared()
    }
}

sealed class AttachmentState {
    data object None : AttachmentState()
    data class Processing(val message: String) : AttachmentState()
    data class Ready(val result: AttachmentResult) : AttachmentState()
    data class Error(val name: String, val message: String) : AttachmentState()
}

sealed class UiState {
    data object Idle : UiState()
    data class Loading(val message: String) : UiState()
    data class Importing(val progress: Int) : UiState()
    data object Generating : UiState()
    data class Streaming(val text: String) : UiState()
    data class Error(val message: String) : UiState()
    data class Success(val message: String) : UiState()
}
