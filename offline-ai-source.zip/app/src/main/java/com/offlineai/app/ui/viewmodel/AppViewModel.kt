package com.offlineai.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.offlineai.app.OfflineAiApp
import com.offlineai.app.data.ConversationEntity
import com.offlineai.app.data.MessageEntity
import com.offlineai.app.domain.MediaPipeEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as OfflineAiApp
    private val db = app.database.chatDao()
    val modelManager = app.modelManager
    val aiEngine = MediaPipeEngine(app)

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState

    private val _currentConversationId = MutableStateFlow<Long?>(null)
    val currentConversationId: StateFlow<Long?> = _currentConversationId

    private val _messages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messages

    private val _conversations = MutableStateFlow<List<ConversationEntity>>(emptyList())
    val conversations: StateFlow<List<ConversationEntity>> = _conversations

    private val _localModels = MutableStateFlow<List<File>>(emptyList())
    val localModels: StateFlow<List<File>> = _localModels

    private val _activeModel = MutableStateFlow<File?>(null)
    val activeModel: StateFlow<File?> = _activeModel

    private val _engineLoaded = MutableStateFlow(false)
    val engineLoaded: StateFlow<Boolean> = _engineLoaded

    init {
        observeConversations()
        refreshModels()
    }

    private fun observeConversations() {
        viewModelScope.launch(Dispatchers.IO) {
            db.getAllConversations().collect {
                _conversations.value = it
            }
        }
    }

    fun refreshModels() {
        _localModels.value = modelManager.getLocalModels()
        _activeModel.value = modelManager.getActiveModel()
        _engineLoaded.value = aiEngine.isLoaded()
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            _uiState.value = UiState.Importing(0)
            val file = modelManager.importModelFromUri(uri) { progress ->
                _uiState.value = UiState.Importing(progress)
            }
            if (file != null) {
                _uiState.value = UiState.Success("Model berhasil diimpor: ${file.name}")
                refreshModels()
            } else {
                _uiState.value = UiState.Error("Gagal mengimpor model. Pastikan file .bin atau .task yang dipilih valid.")
            }
        }
    }

    fun deleteModel(file: File) {
        if (_activeModel.value?.absolutePath == file.absolutePath && aiEngine.isLoaded()) {
            aiEngine.unloadModel()
        }
        modelManager.deleteModel(file)
        refreshModels()
    }

    fun loadModel(file: File) {
        viewModelScope.launch {
            _uiState.value = UiState.Loading("Memuat model ke RAM...")
            try {
                aiEngine.loadModel(file)
                modelManager.setActiveModel(file)
                refreshModels()
                _uiState.value = UiState.Success("Model siap digunakan secara offline.")
            } catch (e: Exception) {
                aiEngine.unloadModel()
                refreshModels()
                _uiState.value = UiState.Error("Gagal memuat model: ${e.message ?: "format model tidak didukung"}")
            }
        }
    }

    fun unloadModel() {
        aiEngine.unloadModel()
        _engineLoaded.value = false
        _uiState.value = UiState.Idle
    }

    fun startNewChat() {
        _currentConversationId.value = null
        _messages.value = emptyList()
        _uiState.value = UiState.Idle
    }

    fun loadChat(conversationId: Long) {
        _currentConversationId.value = conversationId
        viewModelScope.launch(Dispatchers.IO) {
            _messages.value = db.getMessagesForConversation(conversationId).first()
            _uiState.value = UiState.Idle
        }
    }

    fun deleteChat(conversation: ConversationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            db.deleteMessagesByConversation(conversation.id)
            db.deleteConversation(conversation)
            if (_currentConversationId.value == conversation.id) {
                startNewChat()
            }
        }
    }

    fun sendMessage(userText: String) {
        val cleanText = userText.trim()
        if (cleanText.isEmpty()) return
        if (!aiEngine.isLoaded()) {
            _uiState.value = UiState.Error("Model AI belum dimuat. Buka Settings untuk memuat model.")
            return
        }
        if (_uiState.value is UiState.Generating || _uiState.value is UiState.Streaming) return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                var convId = _currentConversationId.value
                if (convId == null) {
                    val title = cleanText.take(40).let { if (cleanText.length > 40) "$it…" else it }
                    convId = db.insertConversation(ConversationEntity(title = title))
                    _currentConversationId.value = convId
                }

                db.insertMessage(MessageEntity(conversationId = convId, role = "user", content = cleanText))
                _messages.value = db.getMessagesForConversationSync(convId)

                val history = db.getMessagesForConversationSync(convId)
                val prompt = buildContextPrompt(history)
                _uiState.value = UiState.Generating

                var assistantResponse = ""
                aiEngine.generateResponseAsync(prompt)
                    .catch { e ->
                        _uiState.value = UiState.Error("Inference gagal: ${e.message ?: "kesalahan tidak diketahui"}")
                    }
                    .collect { chunk ->
                        assistantResponse += chunk
                        _uiState.value = UiState.Streaming(assistantResponse)
                    }

                if (assistantResponse.isNotBlank()) {
                    db.insertMessage(MessageEntity(conversationId = convId, role = "assistant", content = assistantResponse))
                    _messages.value = db.getMessagesForConversationSync(convId)
                }

                if (_uiState.value !is UiState.Error) {
                    _uiState.value = UiState.Idle
                }
            } catch (e: Exception) {
                _uiState.value = UiState.Error("Gagal memproses pesan: ${e.message ?: "kesalahan tidak diketahui"}")
            }
        }
    }

    fun stopGeneration() {
        aiEngine.stopGeneration()
        _uiState.value = UiState.Idle
    }

    private fun buildContextPrompt(history: List<MessageEntity>): String {
        val sb = StringBuilder()
        sb.append("System: Kamu adalah AI assistant yang membantu pengguna secara akurat, jelas, dan aman. Kamu berjalan secara offline di perangkat.\n")
        history.takeLast(12).forEach { msg ->
            when (msg.role) {
                "user" -> sb.append("User: ${msg.content}\n")
                "assistant" -> sb.append("Model: ${msg.content}\n")
            }
        }
        sb.append("Model: ")
        return sb.toString()
    }

    override fun onCleared() {
        aiEngine.unloadModel()
        super.onCleared()
    }
}

sealed class UiState {
    data object Idle : UiState()
    data class Loading(val message: String) : UiState()
    data class Importing(val progress: Int) : UiState()
    data object Generating : UiState()
    data class Streaming(val text: String) : UiState()
    data class Error(val message: String) : UiState()
    data class Success(val message: String) : UiState()
}
