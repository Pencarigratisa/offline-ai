package com.offlineai.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.offlineai.app.OfflineAiApp
import com.offlineai.app.data.ConversationEntity
import com.offlineai.app.data.MessageEntity
import com.offlineai.app.domain.AttachmentProcessor
import com.offlineai.app.domain.AttachmentResult
import com.offlineai.app.domain.MediaPipeEngine
import com.offlineai.app.domain.MathEngine
import com.offlineai.app.domain.OnlineKnowledgeRepository
import com.offlineai.app.data.KnowledgeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as OfflineAiApp
    private val db = app.database.chatDao()
    val modelManager = app.modelManager
    val aiEngine = MediaPipeEngine(app)
    private val attachmentProcessor = AttachmentProcessor(app)
    private val knowledgeRepository = OnlineKnowledgeRepository(app, app.database.knowledgeDao())
    private val learningPrefs = application.getSharedPreferences("offline_ai_learning", android.content.Context.MODE_PRIVATE)

    private fun learningPrefsMode(application: Application): String =
        application.getSharedPreferences("offline_ai_learning", android.content.Context.MODE_PRIVATE)
            .getString("ai_mode", AiMode.OFFLINE.name) ?: AiMode.OFFLINE.name

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState

    private val _currentConversationId = MutableStateFlow<Long?>(null)
    val currentConversationId: StateFlow<Long?> = _currentConversationId

    private val _messages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messages

    private val _conversations = MutableStateFlow<List<ConversationEntity>>(emptyList())
    val conversations: StateFlow<List<ConversationEntity>> = _conversations

    private val _localModels = MutableStateFlow<List<File>>(emptyList())
    val localModels: StateFlow<List<File>> = _localModels

    private val _activeModel = MutableStateFlow<File?>(null)
    val activeModel: StateFlow<File?> = _activeModel

    private val _engineLoaded = MutableStateFlow(false)
    val engineLoaded: StateFlow<Boolean> = _engineLoaded

    private val _attachment = MutableStateFlow<AttachmentState>(AttachmentState.None)

    private val _aiMode = MutableStateFlow(
        runCatching { AiMode.valueOf(learningPrefsMode(application)) }.getOrDefault(AiMode.OFFLINE)
    )
    val aiMode: StateFlow<AiMode> = _aiMode

    private val _learningState = MutableStateFlow<LearningState>(LearningState.Idle)
    val learningState: StateFlow<LearningState> = _learningState

    private val _practiceText = MutableStateFlow("")
    val practiceText: StateFlow<String> = _practiceText
    val attachment: StateFlow<AttachmentState> = _attachment

    init {
        observeConversations()
        refreshModels()
        restoreLearningState()
    }

    private fun restoreLearningState() {
        _practiceText.value = learningPrefs.getString("practice_text", "").orEmpty()
        val topic = learningPrefs.getString("learning_topic", "").orEmpty()
        val count = learningPrefs.getInt("learning_count", 0)
        val savedSuccess = learningPrefs.getBoolean("learning_success", false)
        if (savedSuccess && (topic.isNotBlank() || _practiceText.value.isNotBlank())) {
            _learningState.value = LearningState.Success(count, topic.ifBlank { "Materi tersimpan" })
        }
    }

    private fun saveLearningSnapshot(topic: String, count: Int, success: Boolean) {
        learningPrefs.edit()
            .putString("learning_topic", topic)
            .putInt("learning_count", count)
            .putBoolean("learning_success", success)
            .putString("practice_text", _practiceText.value)
            .apply()
    }

    private fun observeConversations() {
        viewModelScope.launch(Dispatchers.IO) {
            db.getAllConversations().collect {
                _conversations.value = it
            }
        }
    }

    fun refreshModels() {
        _localModels.value = modelManager.getLocalModels()
        _activeModel.value = modelManager.getActiveModel()
        _engineLoaded.value = aiEngine.isLoaded()
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            _uiState.value = UiState.Importing(0)
            val file = modelManager.importModelFromUri(uri) { progress ->
                _uiState.value = UiState.Importing(progress)
            }
            if (file != null) {
                _uiState.value = UiState.Success("Model berhasil diimpor: ${file.name}")
                refreshModels()
            } else {
                _uiState.value = UiState.Error("Gagal mengimpor model. Pastikan file .gguf yang dipilih valid dan kompatibel dengan llama.cpp.")
            }
        }
    }

    fun deleteModel(file: File) {
        if (_activeModel.value?.absolutePath == file.absolutePath && aiEngine.isLoaded()) {
            aiEngine.unloadModel()
        }
        modelManager.deleteModel(file)
        refreshModels()
    }

    fun loadModel(file: File) {
        viewModelScope.launch {
            _uiState.value = UiState.Loading("Memuat model ke RAM...")
            try {
                aiEngine.loadModel(file)
                modelManager.setActiveModel(file)
                refreshModels()
                _uiState.value = UiState.Success("Model siap digunakan secara offline.")
            } catch (e: Exception) {
                aiEngine.unloadModel()
                refreshModels()
                _uiState.value = UiState.Error("Gagal memuat model: ${e.message ?: "format model tidak didukung"}")
            }
        }
    }

    fun unloadModel() {
        aiEngine.unloadModel()
        _engineLoaded.value = false
        _uiState.value = UiState.Idle
    }

    fun startNewChat() {
        _currentConversationId.value = null
        _messages.value = emptyList()
        _uiState.value = UiState.Idle
    }

    fun loadChat(conversationId: Long) {
        _currentConversationId.value = conversationId
        viewModelScope.launch(Dispatchers.IO) {
            _messages.value = db.getMessagesForConversation(conversationId).first()
            _uiState.value = UiState.Idle
        }
    }

    fun deleteChat(conversation: ConversationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            db.deleteMessagesByConversation(conversation.id)
            db.deleteConversation(conversation)
            if (_currentConversationId.value == conversation.id) {
                startNewChat()
            }
        }
    }

    fun attachFile(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _attachment.value = AttachmentState.Processing("Membaca lampiran…")
            val result = attachmentProcessor.process(uri)
            _attachment.value = if (result.success) {
                AttachmentState.Ready(result)
            } else {
                AttachmentState.Error(result.name, result.extractedText)
            }
        }
    }

    fun setAiMode(mode: AiMode) {
        _aiMode.value = mode
        learningPrefs.edit().putString("ai_mode", mode.name).apply()
    }

    fun setOnlineMode(enabled: Boolean) {
        _aiMode.value = if (enabled) AiMode.ONLINE else AiMode.OFFLINE
    }

    fun learnFromInternet(topic: String) {
        val clean = topic.trim()
        if (clean.isEmpty()) return
        learningPrefs.edit()
            .putString("learning_topic", clean)
            .putBoolean("learning_success", false)
            .apply()
        viewModelScope.launch {
            _learningState.value = LearningState.Loading
            val result = knowledgeRepository.searchAndCache(clean, 7)
            _learningState.value = result.fold(
                onSuccess = { items ->
                    saveLearningSnapshot(clean, items.size, true)
                    LearningState.Success(items.size, items.firstOrNull()?.title ?: clean)
                },
                onFailure = {
                    // Keep any knowledge rows already cached before a partial failure.
                    saveLearningSnapshot(clean, 0, false)
                    LearningState.Error(it.message ?: "Gagal mencari materi dari web.")
                }
            )
        }
    }

    fun generatePractice(topic: String) {
        val clean = topic.trim()
        if (clean.isEmpty() || !aiEngine.isLoaded()) return
        viewModelScope.launch(Dispatchers.IO) {
            _learningState.value = LearningState.Loading
            val knowledge = knowledgeRepository.findRelevantOffline(clean, 4)
            val context = knowledge.joinToString("\n\n") { "[${it.title}]\n${it.content.take(3500)}" }
            val prompt = """
                Buat latihan belajar mandiri tentang: $clean
                Gunakan materi berikut bila tersedia:
                $context

                Buat 5 soal bertahap dari mudah ke menantang. Jangan berikan jawaban terlebih dahulu.
                Format setiap soal dengan nomor dan ruang singkat untuk jawaban.
                Di bagian akhir tulis: 'Kirim jawabanmu dan saya akan memeriksanya satu per satu.'
            """.trimIndent()
            runCatching {
                aiEngine.generateResponseAsync(prompt).first()
            }.onSuccess { text ->
                _practiceText.value = text
                saveLearningSnapshot(clean, 0, true)
                _learningState.value = LearningState.Success(0, "Latihan $clean")
            }.onFailure {
                saveLearningSnapshot(clean, 0, false)
                _learningState.value = LearningState.Error(it.message ?: "Gagal membuat latihan.")
            }
        }
    }

    fun clearLearningState() {
        _learningState.value = LearningState.Idle
        _practiceText.value = ""
        learningPrefs.edit().clear().apply()
    }

    fun clearAttachment() {
        _attachment.value = AttachmentState.None
    }

    fun sendMessage(userText: String) {
        val cleanText = userText.trim()
        val currentAttachment = (_attachment.value as? AttachmentState.Ready)?.result
        if (cleanText.isEmpty() && currentAttachment == null) return
        val messageToSave = cleanText.ifBlank { "Analisis lampiran ini." }
        if (!aiEngine.isLoaded()) {
            _uiState.value = UiState.Error("Model AI belum dimuat. Buka Settings untuk memuat model.")
            return
        }
        if (_uiState.value is UiState.Generating || _uiState.value is UiState.Streaming) return

        // Greetings do not need GGUF inference: answer locally and instantly.
        if (currentAttachment == null && isSimpleGreeting(cleanText)) {
            viewModelScope.launch(Dispatchers.IO) {
                val conversationId = _currentConversationId.value
                    ?: db.insertConversation(ConversationEntity(title = messageToSave.take(40))).also {
                        _currentConversationId.value = it
                    }
                db.insertMessage(MessageEntity(conversationId = conversationId, role = "user", content = messageToSave))
                db.insertMessage(MessageEntity(conversationId = conversationId, role = "assistant", content = "Hai! 👋 Ada yang mau kamu tanyakan?"))
                _messages.value = db.getMessagesForConversationSync(conversationId)
                _uiState.value = UiState.Idle
            }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val conversationId = _currentConversationId.value
                    ?: run {
                        val title = messageToSave.take(40).let { if (messageToSave.length > 40) "$it…" else it }
                        db.insertConversation(ConversationEntity(title = title)).also {
                            _currentConversationId.value = it
                        }
                    }

                db.insertMessage(MessageEntity(conversationId = conversationId, role = "user", content = messageToSave))
                _messages.value = db.getMessagesForConversationSync(conversationId)

                // Known school-math forms are solved deterministically before invoking
                // native llama.cpp. This prevents arithmetic mistakes and avoids a
                // native inference path for calculations that do not need generation.
                val deterministicAnswer = MathEngine.solveIfSupported(messageToSave)
                if (deterministicAnswer != null && currentAttachment == null) {
                    _uiState.value = UiState.Streaming(deterministicAnswer)
                    db.insertMessage(MessageEntity(conversationId = conversationId, role = "assistant", content = deterministicAnswer))
                    _messages.value = db.getMessagesForConversationSync(conversationId)
                    _uiState.value = UiState.Idle
                    return@launch
                }

                val history = db.getMessagesForConversationSync(conversationId)
                val knowledge = when (_aiMode.value) {
                    AiMode.ONLINE -> if (cleanText.isNotBlank()) {
                        knowledgeRepository.searchAndCache(cleanText, 5).getOrNull().orEmpty()
                    } else emptyList()
                    AiMode.OFFLINE, AiMode.LEARN -> knowledgeRepository.findRelevantOffline(cleanText)
                }
                val prompt = buildContextPrompt(history, currentAttachment, knowledge, _aiMode.value)
                _uiState.value = UiState.Generating

                var assistantResponse = ""
                aiEngine.generateResponseAsync(prompt)
                    .catch { e ->
                        _uiState.value = UiState.Error("Inference gagal: ${e.message ?: "kesalahan tidak diketahui"}")
                    }
                    .collect { chunk ->
                        assistantResponse += chunk
                        _uiState.value = UiState.Streaming(assistantResponse)
                    }

                if (assistantResponse.isNotBlank()) {
                    db.insertMessage(MessageEntity(conversationId = conversationId, role = "assistant", content = assistantResponse))
                    _messages.value = db.getMessagesForConversationSync(conversationId)
                }

                if (_uiState.value !is UiState.Error) {
                    _attachment.value = AttachmentState.None
                    _uiState.value = UiState.Idle
                }
            } catch (e: Exception) {
                _uiState.value = UiState.Error("Gagal memproses pesan: ${e.message ?: "kesalahan tidak diketahui"}")
            }
        }
    }

    fun stopGeneration() {
        aiEngine.stopGeneration()
        _uiState.value = UiState.Idle
    }

    private fun isSimpleGreeting(text: String): Boolean {
        val normalized = text.lowercase()
            .replace(Regex("[^a-zA-ZÀ-ÿ\\s]"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
        return normalized in setOf("hai", "halo", "hi", "hello", "hei", "hallo", "pagi", "siang", "sore", "malam")
    }

    private fun buildContextPrompt(
        history: List<MessageEntity>,
        attachment: AttachmentResult? = null,
        knowledge: List<KnowledgeEntity> = emptyList(),
        mode: AiMode = AiMode.OFFLINE
    ): String {
        val recent = history.takeLast(6)
        val latestUser = recent.lastOrNull { it.role == "user" }?.content.orEmpty().take(2600)
        val previous = recent.dropLast(1).takeLast(4)

        val sb = StringBuilder()
        sb.append("Mode aplikasi: ${mode.label}\n")
        when (mode) {
            AiMode.ONLINE -> sb.append("Gunakan materi web terbaru yang disediakan sebagai sumber tambahan. Bedakan fakta dari sumber dan jangan mengarang.\n\n")
            AiMode.OFFLINE -> sb.append("Jangan mengandalkan internet. Gunakan hanya pengetahuan model dan Knowledge Base lokal yang diberikan.\n\n")
            AiMode.LEARN -> sb.append("Bertindak sebagai tutor. Gunakan Knowledge Base lokal sebagai bahan belajar dan jelaskan secara bertahap.\n\n")
        }
        if (previous.isNotEmpty()) {
            sb.append("Konteks percakapan sebelumnya:\n")
            previous.forEach { msg ->
                when (msg.role) {
                    "user" -> sb.append("Pengguna: ${msg.content.take(900)}\n")
                    "assistant" -> sb.append("Asisten: ${msg.content.take(900)}\n")
                }
            }
            sb.append('\n')
        }

        if (attachment != null) {
            sb.append("Lampiran yang harus dianalisis: ${attachment.name}\n")
            sb.append("Isi hasil pembacaan/OCR lampiran:\n")
            sb.append(attachment.extractedText.take(4200))
            sb.append("\n\n")
        }

        if (knowledge.isNotEmpty()) {
            // IMPORTANT: llama.cpp is configured with a 2048-token context.
            // A learned topic can have several cached web sources, and putting
            // thousands of characters from every source into one prompt can
            // exceed the native context and cause a force-close/abort.
            // Keep only compact, relevant excerpts and enforce a hard prompt
            // budget before native inference.
            sb.append("Pengetahuan tambahan dari sumber yang telah diambil/tersimpan:\n")
            knowledge.distinctBy { it.title }.take(3).forEach { item ->
                sb.append("[${item.title.take(140)}]\n")
                sb.append(item.content.take(800))
                sb.append("\nSumber: ${item.sourceUrl.take(240)}\n\n")
            }
            sb.append("Gunakan sumber di atas sebagai konteks. Jika tidak cukup untuk menjawab, katakan dengan jujur. Jangan mengarang fakta yang tidak ada di sumber.\n\n")
        }

        if (latestUser.isNotBlank()) {
            sb.append("Pertanyaan pengguna saat ini:\n")
            sb.append(latestUser)
        } else if (attachment != null) {
            sb.append("Tolong analisis lampiran tersebut dan jelaskan hal-hal penting yang dapat disimpulkan dari isinya.")
        }
        // Final hard limit for the native llama.cpp prompt. This is deliberately
        // conservative for a 2048-token context because the AAR also adds the
        // system prompt and chat-template tokens internally.
        return sb.toString().trim().take(6500)
    }

    override fun onCleared() {
        aiEngine.unloadModel()
        super.onCleared()
    }
}

enum class AiMode(val label: String) {
    ONLINE("Online"),
    OFFLINE("Offline"),
    LEARN("Belajar")
}

sealed class LearningState {
    data object Idle : LearningState()
    data object Loading : LearningState()
    data class Success(val count: Int, val topic: String) : LearningState()
    data class Error(val message: String) : LearningState()
}

sealed class AttachmentState {
    data object None : AttachmentState()
    data class Processing(val message: String) : AttachmentState()
    data class Ready(val result: AttachmentResult) : AttachmentState()
    data class Error(val name: String, val message: String) : AttachmentState()
}

sealed class UiState {
    data object Idle : UiState()
    data class Loading(val message: String) : UiState()
    data class Importing(val progress: Int) : UiState()
    data object Generating : UiState()
    data class Streaming(val text: String) : UiState()
    data class Error(val message: String) : UiState()
    data class Success(val message: String) : UiState()
}
