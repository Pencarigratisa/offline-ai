package com.offlineai.app

import android.app.Application
import androidx.room.Room
import com.offlineai.app.data.AppDatabase
import com.offlineai.app.domain.ModelManager

class OfflineAiApp : Application() {
    lateinit var database: AppDatabase
        private set

    lateinit var modelManager: ModelManager
        private set

    override fun onCreate() {
        super.onCreate()

        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "offline_ai_database"
        ).fallbackToDestructiveMigration().build()

        modelManager = ModelManager(applicationContext)
    }
}
