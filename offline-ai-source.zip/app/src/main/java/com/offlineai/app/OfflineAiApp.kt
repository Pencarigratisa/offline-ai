package com.offlineai.app

import android.app.Application
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.offlineai.app.data.AppDatabase
import com.offlineai.app.domain.ModelManager

class OfflineAiApp : Application() {
    lateinit var database: AppDatabase
        private set

    lateinit var modelManager: ModelManager
        private set

    override fun onCreate() {
        super.onCreate()

        val migration1to2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS knowledge (title TEXT NOT NULL PRIMARY KEY, content TEXT NOT NULL, sourceUrl TEXT NOT NULL, learnedAt INTEGER NOT NULL)")
            }
        }
        val migration2to3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE knowledge ADD COLUMN sourceType TEXT NOT NULL DEFAULT 'web'")
            }
        }
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "offline_ai_database"
        ).addMigrations(migration1to2, migration2to3).build()

        modelManager = ModelManager(applicationContext)
    }
}
