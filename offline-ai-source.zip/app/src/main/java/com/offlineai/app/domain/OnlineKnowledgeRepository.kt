package com.offlineai.app.domain

import android.content.Context
import com.offlineai.app.data.KnowledgeDao
import com.offlineai.app.data.KnowledgeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Multi-source online retrieval layer.
 * It does not retrain Qwen weights. It searches the public web, extracts small
 * text passages, caches them locally, and lets the local model use them later.
 */
class OnlineKnowledgeRepository(
    private val context: Context,
    private val dao: KnowledgeDao
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun searchAndCache(query: String, limit: Int = 6): Result<List<KnowledgeEntity>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val q = query.trim()
                require(q.isNotBlank()) { "Kata pencarian kosong." }

                val candidates = mutableListOf<SearchHit>()
                candidates += duckSearch(q, 5)
                candidates += duckSearch("site:id.wikipedia.org $q", 3)
                candidates += duckSearch("site:openstax.org $q", 3)
                candidates += duckSearch("site:khanacademy.org $q", 2)

                val unique = candidates
                    .distinctBy { normalizeUrl(it.url) }
                    .take(limit.coerceIn(1, 8))

                val saved = unique.mapNotNull { hit ->
                    val pageText = fetchReadableText(hit.url)
                    val content = (pageText.ifBlank { hit.snippet }).cleanText()
                    if (content.length < 80) return@mapNotNull null
                    val domain = runCatching { java.net.URI(hit.url).host.orEmpty() }.getOrDefault("")
                    KnowledgeEntity(
                        title = "${domain.ifBlank { "Web" }} — ${hit.title}".take(180),
                        content = content.take(MAX_KNOWLEDGE_CHARS),
                        sourceUrl = hit.url,
                        learnedAt = System.currentTimeMillis(),
                        sourceType = sourceTypeFor(domain)
                    ).also { dao.upsertKnowledge(it) }
                }

                if (saved.isEmpty()) error("Tidak menemukan materi web yang bisa dibaca.")
                saved
            }
        }

    /** Kept for compatibility with the Learn screen and older code. */
    suspend fun learnTopic(topic: String): Result<List<KnowledgeEntity>> = searchAndCache(topic, 7)

    suspend fun findRelevantOffline(query: String, limit: Int = 5): List<KnowledgeEntity> =
        withContext(Dispatchers.IO) {
            val tokens = query.lowercase()
                .split(Regex("[^\\p{L}\\p{N}]+"))
                .filter { it.length >= 3 }
                .distinct()
                .take(14)
            if (tokens.isEmpty()) return@withContext emptyList()
            val all = dao.getAllKnowledge()
            all.asSequence()
                .map { item ->
                    val hay = (item.title + " " + item.content).lowercase()
                    val score = tokens.sumOf { token ->
                        when {
                            hay.contains(" $token ") -> 3
                            hay.contains(token) -> 1
                            else -> 0
                        }
                    }
                    item to score
                }
                .filter { it.second > 0 }
                .sortedByDescending { it.second }
                .take(limit)
                .map { it.first }
                .toList()
        }

    private fun duckSearch(query: String, limit: Int): List<SearchHit> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://html.duckduckgo.com/html/?q=$encoded"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Android) OfflineAI/1.4")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return emptyList()
            val html = response.body?.string().orEmpty()
            val results = mutableListOf<SearchHit>()
            val pattern = Regex(
                "<a[^>]*class=\\\"result__a\\\"[^>]*href=\\\"([^\\\"]+)\\\"[^>]*>(.*?)</a>(.*?)(?=<div class=\\\"result|$)",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )
            for (m in pattern.findAll(html).take(limit)) {
                val rawUrl = htmlDecode(m.groupValues[1])
                val link = if (rawUrl.contains("uddg=")) {
                    runCatching {
                        val part = rawUrl.substringAfter("uddg=").substringBefore("&")
                        URLDecoder.decode(part, "UTF-8")
                    }.getOrDefault(rawUrl)
                } else rawUrl
                if (!link.startsWith("http")) continue
                val title = stripTags(m.groupValues[2]).cleanText()
                val block = stripTags(m.groupValues[3]).cleanText()
                results += SearchHit(title.ifBlank { link }, link, block.take(900))
            }
            return results
        }
    }

    private fun fetchReadableText(url: String): String {
        return runCatching {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android) OfflineAI/1.4")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return ""
                val html = response.body?.string().orEmpty().take(700_000)
                stripTags(
                    html
                        .replace(Regex("(?is)<script.*?</script>"), " ")
                        .replace(Regex("(?is)<style.*?</style>"), " ")
                        .replace(Regex("(?is)<nav.*?</nav>"), " ")
                        .replace(Regex("(?is)<footer.*?</footer>"), " ")
                ).cleanText()
            }
        }.getOrDefault("")
    }

    private fun stripTags(value: String): String =
        value.replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")

    private fun htmlDecode(value: String): String = stripTags(value)

    private fun String.cleanText(): String =
        replace(Regex("\\s+"), " ").trim()

    private fun normalizeUrl(url: String): String = url.substringBefore("#").trimEnd('/')

    private fun sourceTypeFor(domain: String): String = when {
        domain.contains("wikipedia.org") -> "Wikipedia"
        domain.contains("openstax.org") -> "OpenStax"
        domain.contains("khanacademy.org") -> "Khan Academy"
        else -> "Web Search"
    }

    private data class SearchHit(val title: String, val url: String, val snippet: String)

    companion object {
        private const val MAX_KNOWLEDGE_CHARS = 8500
    }
}
