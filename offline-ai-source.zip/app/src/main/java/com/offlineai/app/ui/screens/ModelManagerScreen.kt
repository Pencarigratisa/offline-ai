package com.offlineai.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offlineai.app.ui.viewmodel.AppViewModel
import com.offlineai.app.ui.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelManagerScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    val localModels by viewModel.localModels.collectAsState()
    val activeModel by viewModel.activeModel.collectAsState()
    val engineLoaded by viewModel.engineLoaded.collectAsState()
    val uiState by viewModel.uiState.collectAsState()

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.importModel(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manage Models") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                filePickerLauncher.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*"))
            }) {
                Icon(Icons.Default.Upload, contentDescription = "Import Model")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                "Info: Gunakan model GGUF (.gguf) yang kompatibel dengan llama.cpp. Contoh: Qwen2.5-1.5B-Instruct Q8_0.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))

            when (val state = uiState) {
                is UiState.Importing -> {
                    // Avoid Material3 ProgressIndicator here. The previous build crashed at runtime
                    // with NoSuchMethodError inside ProgressIndicator/Compose animation classes.
                    Text("Mengimpor model... ${state.progress}%")
                    Spacer(modifier = Modifier.height(16.dp))
                }
                is UiState.Loading -> {
                    // Keep loading state simple and animation-free so a Compose binary mismatch
                    // cannot crash the model manager before the GGUF engine is reached.
                    Text(state.message)
                    Spacer(modifier = Modifier.height(16.dp))
                }
                is UiState.Error -> {
                    Text("Error: ${state.message}", color = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.height(16.dp))
                }
                is UiState.Success -> {
                    Text(state.message, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(16.dp))
                }
                else -> {}
            }

            Text("Model Terpasang", style = MaterialTheme.typography.titleMedium)
            Divider(modifier = Modifier.padding(vertical = 8.dp))

            if (localModels.isEmpty()) {
                Text("Belum ada model. Klik tombol import untuk menambahkan.")
            } else {
                LazyColumn {
                    items(localModels) { file ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (activeModel == file && engineLoaded) 
                                    MaterialTheme.colorScheme.primaryContainer 
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(file.name, style = MaterialTheme.typography.bodyLarge)
                                Text("Size: ${file.length() / (1024 * 1024)} MB", style = MaterialTheme.typography.bodySmall)
                                
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    if (activeModel == file && engineLoaded) {
                                        Button(onClick = { viewModel.unloadModel() }) {
                                            Text("Unload")
                                        }
                                    } else {
                                        Button(onClick = { viewModel.loadModel(file) }) {
                                            Text("Load to RAM")
                                        }
                                    }
                                    
                                    IconButton(onClick = { viewModel.deleteModel(file) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
