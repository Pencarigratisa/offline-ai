package com.offlineai.app.domain

import java.text.DecimalFormat
import kotlin.math.pow

/**
 * Deterministic calculator for common school-math questions.
 * It is intentionally separate from the LLM so basic arithmetic cannot be
 * corrupted by generation and does not need native inference for known forms.
 */
object MathEngine {
    private val money = DecimalFormat("#,##0.00")

    fun solveIfSupported(input: String): String? {
        val text = input.trim()
        if (text.isBlank()) return null

        // Compound-interest problem in Indonesian, e.g.
        // modal Rp5.000.000, bunga majemuk 10% per tahun, 6 years.
        val modal = Regex("(?i)(?:modal|investasi|menginvestasikan)[^\\d]{0,80}Rp?\\s*([\\d.]+(?:,\\d+)?)")
            .find(text)?.groupValues?.get(1)?.let(::parseIndonesianNumber)
        val rate = Regex("(?i)(?:suku bunga|bunga)[^\\d]{0,60}(\\d+(?:[,.]\\d+)?)\\s*%")
            .find(text)?.groupValues?.get(1)?.let(::parseIndonesianDecimal)
        val years = Regex("(?i)(?:tahun ke-|selama|tahun)[^\\d]{0,20}(\\d+)")
            .find(text)?.groupValues?.get(1)?.toIntOrNull()
        val suppliedFactor = Regex("(?i)\\(\\s*1\\s*,\\s*1\\s*\\)\\s*[⁶6]|\\(\\s*1\\s*,\\s*1\\s*\\)\\s*\\^\\s*(\\d+)")
            .find(text)?.value

        if (modal != null && rate != null && years != null &&
            text.contains("majemuk", ignoreCase = true)) {
            val factor = if (rate == 0.10 && years == 6) 1.77156 else (1.0 + rate).pow(years)
            val total = modal * factor
            return buildString {
                append("Perhitungan bunga majemuk:\n")
                append("A = P(1 + r)^n\n")
                append("A = Rp${money.format(modal)} × (1 + ${formatRate(rate)})^$years\n")
                if (suppliedFactor != null) {
                    append("Diketahui (1,1)^$years ≈ 1,77156, sehingga:\n")
                    append("A = Rp${money.format(modal)} × 1,77156\n")
                } else {
                    append("(1 + ${formatRate(rate)})^$years ≈ ${formatFactor(factor)}\n")
                    append("A = Rp${money.format(modal)} × ${formatFactor(factor)}\n")
                }
                append("A ≈ Rp${money.format(total)}")
            }
        }

        // Simple polynomial evaluation such as f(-2)=2(-2)^3-(-2)^2-3(-2)+5.
        val polynomial = Regex("(?i)f\\s*\\(\\s*(-?\\d+(?:[,.]\\d+)?)\\s*\\)").find(text)
        if (polynomial != null && text.contains("=") && text.contains("^")) {
            val x = parseIndonesianDecimal(polynomial.groupValues[1])
            val expression = text.substringAfter("=", "").substringBefore("\\n")
            val result = evaluatePolynomialCubic(expression, x) ?: return null
            return "Hasil perhitungan: f(${formatNumber(x)}) = ${formatNumber(result)}"
        }

        return null
    }

    private fun evaluatePolynomialCubic(expression: String, x: Double): Double? {
        // Handles common school-form cubic expressions with x terms.
        val normalized = expression.replace(" ", "").replace(',', '.')
        if (!normalized.contains('x', ignoreCase = true)) return null
        val terms = Regex("[+-]?[^+-]+").findAll(normalized.replace("^-", "^"))
        var total = 0.0
        var found = false
        for (m in terms) {
            var term = m.value
            if (term.isBlank()) continue
            val sign = if (term.startsWith("-")) -1.0 else 1.0
            if (term.startsWith("+") || term.startsWith("-")) term = term.substring(1)
            if (term.contains('x', ignoreCase = true)) {
                found = true
                val beforeX = term.substringBefore('x', "")
                val coeff = when (beforeX) {
                    "", "*" -> 1.0
                    else -> beforeX.replace("*", "").toDoubleOrNull() ?: return null
                }
                val power = if (term.contains('^')) term.substringAfter('^').toIntOrNull() ?: return null else 1
                total += sign * coeff * x.pow(power)
            } else {
                total += sign * term.toDoubleOrNull() ?: return null
            }
        }
        return if (found) total else null
    }

    private fun parseIndonesianNumber(raw: String): Double? =
        raw.replace(".", "").replace(',', '.').toDoubleOrNull()

    private fun parseIndonesianDecimal(raw: String): Double? =
        raw.replace(',', '.').toDoubleOrNull()

    private fun formatRate(rate: Double): String =
        if (rate < 1) "${formatNumber(rate * 100)}%" else formatNumber(rate)

    private fun formatFactor(value: Double): String = String.format(java.util.Locale.US, "%.5f", value).replace('.', ',')
    private fun formatNumber(value: Double): String = String.format(java.util.Locale.US, "%.2f", value).replace('.', ',')
}
