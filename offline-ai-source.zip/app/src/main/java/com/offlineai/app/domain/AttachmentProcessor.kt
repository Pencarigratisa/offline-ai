package com.offlineai.app.domain

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import java.io.File

/**
 * Offline document/image reader.
 * - Images/camera: OCR with bundled ML Kit.
 * - PDF: render pages with Android PdfRenderer, then OCR each page.
 * This intentionally avoids a full vision model so the app stays much more stable
 * on mid-range devices. The extracted text is passed to the local GGUF model.
 */
class AttachmentProcessor(private val context: Context) {
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun process(uri: Uri, displayName: String? = null): AttachmentResult = withContext(Dispatchers.IO) {
        val name = displayName ?: queryName(uri) ?: "Lampiran"
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        val extension = name.substringAfterLast('.', "").lowercase()

        return@withContext when {
            mime == "application/pdf" || extension == "pdf" -> processPdf(uri, name)
            mime.startsWith("image/") || extension in setOf("jpg", "jpeg", "png", "webp", "heic", "heif") -> processImage(uri, name)
            else -> AttachmentResult(name, "Format belum didukung. Gunakan PDF atau gambar.", false)
        }
    }

    private suspend fun processImage(uri: Uri, name: String): AttachmentResult {
        return try {
            val image = InputImage.fromFilePath(context, uri)
            val result = recognizer.process(image).await()
            val text = result.text.trim()
            if (text.isBlank()) {
                AttachmentResult(name, "Tidak ditemukan teks yang terbaca pada gambar.", true)
            } else {
                AttachmentResult(name, text.take(MAX_TEXT_CHARS), true)
            }
        } catch (e: Exception) {
            AttachmentResult(name, "Gagal membaca gambar: ${e.message ?: "kesalahan OCR"}", false)
        }
    }

    private suspend fun processPdf(uri: Uri, name: String): AttachmentResult {
        var descriptor: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        return try {
            descriptor = context.contentResolver.openFileDescriptor(uri, "r")
                ?: return AttachmentResult(name, "PDF tidak dapat dibuka.", false)
            renderer = PdfRenderer(descriptor)
            val pageCount = renderer.pageCount
            val pagesToRead = minOf(pageCount, MAX_PDF_PAGES)
            val allText = StringBuilder()

            for (index in 0 until pagesToRead) {
                if (allText.length >= MAX_TEXT_CHARS) break
                val page = renderer.openPage(index)
                try {
                    val width = 1200
                    val scale = width.toFloat() / page.width.coerceAtLeast(1)
                    val height = (page.height * scale).toInt().coerceIn(400, 1800)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val ocr = recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
                    val pageText = ocr.text.trim()
                    if (pageText.isNotBlank()) {
                        allText.append("\n--- Halaman ${index + 1} ---\n")
                        allText.append(pageText)
                        allText.append('\n')
                    }
                    bitmap.recycle()
                } finally {
                    page.close()
                }
            }

            val note = if (pageCount > pagesToRead) {
                "\n[PDF memiliki $pageCount halaman; untuk menjaga RAM, hanya $pagesToRead halaman pertama yang dibaca.]"
            } else ""
            val text = (allText.toString().trim() + note).trim()
            AttachmentResult(
                name,
                if (text.isBlank()) "PDF berhasil dibuka, tetapi tidak ada teks yang terbaca." else text.take(MAX_TEXT_CHARS),
                true
            )
        } catch (e: Exception) {
            AttachmentResult(name, "Gagal membaca PDF: ${e.message ?: "kesalahan PDF/OCR"}", false)
        } finally {
            runCatching { renderer?.close() }
            runCatching { descriptor?.close() }
        }
    }

    private fun queryName(uri: Uri): String? = context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        if (!cursor.moveToFirst()) return@use null
        val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (index >= 0) cursor.getString(index) else null
    }

    companion object {
        private const val MAX_PDF_PAGES = 8
        private const val MAX_TEXT_CHARS = 14000
    }
}

data class AttachmentResult(
    val name: String,
    val extractedText: String,
    val success: Boolean
)
