package com.offlineai.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offlineai.app.ui.viewmodel.AiMode
import com.offlineai.app.ui.viewmodel.AppViewModel
import com.offlineai.app.ui.viewmodel.LearningState

@Composable
fun LearnScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    var topic by remember { mutableStateOf("") }
    val state by viewModel.learningState.collectAsState()
    val practice by viewModel.practiceText.collectAsState()
    val scroll = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mode Belajar") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Kembali") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp).verticalScroll(scroll),
            verticalArrangement = Arrangement.Top
        ) {
            Text("3 mode Offline AI", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(6.dp))
            Text("Online mencari materi dari web, Offline memakai materi yang sudah tersimpan, dan Belajar membantu membuat latihan mandiri.")
            Spacer(Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeButton("Online", viewModel.aiMode.collectAsState().value == AiMode.ONLINE) { viewModel.setAiMode(AiMode.ONLINE) }
                ModeButton("Offline", viewModel.aiMode.collectAsState().value == AiMode.OFFLINE) { viewModel.setAiMode(AiMode.OFFLINE) }
                ModeButton("Belajar", true) { viewModel.setAiMode(AiMode.LEARN) }
            }

            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = topic,
                onValueChange = { topic = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Topik") },
                placeholder = { Text("Contoh: fluida dinamis, polinomial, sistem pernapasan") },
                minLines = 2
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { viewModel.learnFromInternet(topic) },
                enabled = topic.isNotBlank() && state !is LearningState.Loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state is LearningState.Loading) CircularProgressIndicator(modifier = Modifier.height(20.dp), strokeWidth = 2.dp)
                else {
                    Icon(Icons.Default.CloudDownload, contentDescription = null)
                    Spacer(Modifier.padding(horizontal = 4.dp))
                    Text("Cari web & simpan materi")
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = { viewModel.generatePractice(topic) },
                enabled = topic.isNotBlank() && state !is LearningState.Loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.MenuBook, contentDescription = null)
                Spacer(Modifier.padding(horizontal = 4.dp))
                Text("Buat 5 soal latihan")
            }

            Spacer(Modifier.height(14.dp))
            when (val s = state) {
                LearningState.Idle -> Text("Belum ada proses belajar.")
                LearningState.Loading -> Text("Mencari sumber dan menyiapkan materi…")
                is LearningState.Success -> Text(if (s.count > 0) "Tersimpan ${s.count} sumber: ${s.topic}" else "Latihan berhasil dibuat.")
                is LearningState.Error -> Text("Gagal: ${s.message}", color = MaterialTheme.colorScheme.error)
            }

            if (practice.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Text("Latihan mandiri", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(practice)
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "Sumber online dapat berasal dari Wikipedia, OpenStax, Khan Academy, dan hasil Web Search. Materi yang berhasil dibaca disimpan lokal agar dapat dipakai saat Offline. Ini bukan fine-tuning bobot Qwen.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick, modifier = Modifier.weight(1f)) { Text(label) }
    else OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f)) { Text(label) }
}
