package com.offlineai.app.domain

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import java.io.File

interface LocalAiEngine {
    suspend fun loadModel(modelFile: File)
    fun unloadModel()
    fun isLoaded(): Boolean
    fun generateResponseAsync(prompt: String): Flow<String>
    fun stopGeneration()
}

class MediaPipeEngine(private val context: Context) : LocalAiEngine {
    private var llmInference: LlmInference? = null
    @Volatile private var isGenerating = false

    override suspend fun loadModel(modelFile: File) {
        require(modelFile.exists() && modelFile.isFile) { "Model file tidak ditemukan." }
        withContext(Dispatchers.IO) {
            unloadModel()
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(1024)
                .setTemperature(0.7f)
                .setResultListener { partialResult, _ ->
                    // Result delivery is handled by generateResponseAsync's listener below.
                }
                .build()
            llmInference = LlmInference.createFromOptions(context, options)
        }
    }

    override fun unloadModel() {
        isGenerating = false
        llmInference?.close()
        llmInference = null
    }

    override fun isLoaded(): Boolean = llmInference != null

    override fun generateResponseAsync(prompt: String): Flow<String> = callbackFlow {
        val engine = llmInference
        if (engine == null) {
            close(IllegalStateException("Model belum dimuat."))
            return@callbackFlow
        }

        isGenerating = true
        try {
            engine.generateResponseAsync(prompt) { partialResult, done ->
                if (!isGenerating) return@generateResponseAsync
                if (partialResult.isNotEmpty()) trySend(partialResult)
                if (done) {
                    isGenerating = false
                    close()
                }
            }
        } catch (t: Throwable) {
            isGenerating = false
            close(t)
        }

        awaitClose {
            isGenerating = false
        }
    }

    override fun stopGeneration() {
        // The 0.10.14 LlmInference API exposes generation cancellation through its
        // stateful session API. This app intentionally uses the simpler stateless API;
        // stopping here prevents additional UI chunks from being emitted.
        isGenerating = false
    }
}
