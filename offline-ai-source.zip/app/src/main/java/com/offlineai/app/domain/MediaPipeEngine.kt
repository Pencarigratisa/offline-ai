package com.offlineai.app.domain

import android.content.Context
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.reflect.KParameter
import kotlin.reflect.full.callSuspend
import kotlin.reflect.full.memberProperties
import kotlin.reflect.full.objectInstance
import kotlin.reflect.full.declaredFunctions
import java.io.File

/**
 * Local GGUF engine backed by llama.cpp.
 *
 * The class keeps the public engine name used by the original app so the rest
 * of the UI/ViewModel does not need to change. The model handle is stored as
 * Any because the prebuilt AAR does not require the app to expose its internal
 * native model type. Kotlin reflection calls the documented suspend API.
 */
interface LocalAiEngine {
    suspend fun loadModel(modelFile: File)
    fun unloadModel()
    fun isLoaded(): Boolean
    fun generateResponseAsync(prompt: String): Flow<String>
    fun stopGeneration()
}

class MediaPipeEngine(private val context: Context) : LocalAiEngine {
    @Volatile private var modelHandle: Any? = null
    @Volatile private var modelFile: File? = null
    @Volatile private var isGenerating = false

    override suspend fun loadModel(modelFile: File) {
        require(modelFile.exists() && modelFile.isFile) { "Model file tidak ditemukan." }
        require(modelFile.extension.equals("gguf", true)) {
            "Engine baru ini membutuhkan model GGUF (.gguf)."
        }

        withContext(Dispatchers.IO) {
            unloadModel()
            val config = LlamaConfig(
                contextSize = 4096,
                threads = 4
            )
            val llamaObject = Llama::class.objectInstance
                ?: error("Llama engine tidak tersedia di library.")

            val function = Llama::class.declaredFunctions.firstOrNull { fn ->
                fn.name == "loadModel" && fn.isSuspend
            } ?: error("API loadModel tidak ditemukan pada llama-android.")

            val params = function.parameters
            val args = linkedMapOf<KParameter, Any?>(params.first() to llamaObject)
            params.drop(1).forEach { parameter ->
                when (parameter.name) {
                    "modelPath" -> args[parameter] = modelFile.absolutePath
                    "config" -> args[parameter] = config
                }
            }
            check(args.size == params.size) { "Signature loadModel tidak didukung oleh versi library." }

            val loaded = function.callSuspendBySafe(args)
            modelHandle = loaded
            this@MediaPipeEngine.modelFile = modelFile
        }
    }

    override fun unloadModel() {
        isGenerating = false
        val handle = modelHandle ?: run {
            modelFile = null
            return
        }
        modelHandle = null
        modelFile = null

        // releaseModel is a native cleanup operation. Run it on a worker thread
        // when possible; do not block the Compose/UI thread.
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                val llamaObject = Llama::class.objectInstance ?: return@runCatching
                val function = Llama::class.declaredFunctions.firstOrNull { fn ->
                    fn.name == "releaseModel" && fn.isSuspend
                } ?: return@runCatching
                val params = function.parameters
                if (params.size == 2) {
                    function.callSuspendBySafe(linkedMapOf(params[0] to llamaObject, params[1] to handle))
                }
            }
        }
    }

    override fun isLoaded(): Boolean = modelHandle != null && modelFile?.exists() == true

    override fun generateResponseAsync(prompt: String): Flow<String> = callbackFlow {
        val handle = modelHandle
        if (handle == null) {
            close(IllegalStateException("Model belum dimuat."))
            return@callbackFlow
        }

        isGenerating = true
        try {
            val llamaObject = Llama::class.objectInstance
                ?: error("Llama engine tidak tersedia di library.")
            val function = Llama::class.declaredFunctions.firstOrNull { fn ->
                fn.name == "complete" && fn.isSuspend
            } ?: error("API complete tidak ditemukan pada llama-android.")

            val params = function.parameters
            val args = linkedMapOf<KParameter, Any?>(params.first() to llamaObject)
            params.drop(1).forEach { parameter ->
                when (parameter.name) {
                    "model" -> args[parameter] = handle
                    "prompt" -> args[parameter] = prompt
                    "systemPrompt" -> args[parameter] = """
                        Kamu adalah Offline AI, asisten AI lokal yang berjalan sepenuhnya di perangkat pengguna.
                        Selalu utamakan bahasa Indonesia jika pengguna berbicara bahasa Indonesia.
                        Jawab dengan jelas, natural, ringkas tetapi membantu. Jangan mengaku memiliki akses internet.
                    """.trimIndent()
                    "maxTokens" -> args[parameter] = 512
                }
            }
            check(args.size == params.size) { "Signature complete tidak didukung oleh versi library." }

            val result = function.callSuspendBySafe(args)
            val text = result.readTextProperty()
            if (isGenerating && text.isNotBlank()) {
                trySend(text).isSuccess
            }
            isGenerating = false
            close()
        } catch (t: Throwable) {
            isGenerating = false
            close(t.cause ?: t)
        }

        awaitClose {
            isGenerating = false
        }
    }

    override fun stopGeneration() {
        // The free AAR exposes non-streaming completion, so this can only stop
        // forwarding/accepting the current result. A later streaming build can
        // use the Pro Flow API or a direct llama.cpp binding for true cancel.
        isGenerating = false
    }
}

private suspend fun kotlin.reflect.KFunction<*>.callSuspendBySafe(
    args: Map<KParameter, Any?>
): Any? = callSuspendBy(args)

private fun Any?.readTextProperty(): String {
    if (this == null) return ""
    val property = this::class.memberProperties.firstOrNull { it.name == "text" }
        ?: error("Hasil inference tidak memiliki properti text.")
    return property.getter.call(this)?.toString().orEmpty()
}
