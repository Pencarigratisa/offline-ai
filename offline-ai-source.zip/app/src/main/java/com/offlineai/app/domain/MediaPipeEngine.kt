package com.offlineai.app.domain

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

interface LocalAiEngine {
    suspend fun loadModel(modelFile: File)
    fun unloadModel()
    fun isLoaded(): Boolean
    fun generateResponseAsync(prompt: String): Flow<String>
    fun stopGeneration()
}

class MediaPipeEngine(private val context: Context) : LocalAiEngine {
    private var llmInference: LlmInference? = null
    @Volatile private var isGenerating = false

    // MediaPipe 0.10.14 delivers async partial results through the
    // ResultListener configured in LlmInferenceOptions. The public
    // generateResponseAsync(String) method itself only takes the prompt.
    @Volatile
    private var resultSink: ((String, Boolean) -> Unit)? = null

    override suspend fun loadModel(modelFile: File) {
        require(modelFile.exists() && modelFile.isFile) { "Model file tidak ditemukan." }
        withContext(Dispatchers.IO) {
            unloadModel()
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(1024)
                .setTemperature(0.7f)
                .setResultListener { partialResult, done ->
                    resultSink?.invoke(partialResult, done)
                }
                .build()
            llmInference = LlmInference.createFromOptions(context, options)
        }
    }

    override fun unloadModel() {
        isGenerating = false
        resultSink = null
        llmInference?.close()
        llmInference = null
    }

    override fun isLoaded(): Boolean = llmInference != null

    override fun generateResponseAsync(prompt: String): Flow<String> = callbackFlow {
        val engine = llmInference
        if (engine == null) {
            close(IllegalStateException("Model belum dimuat."))
            return@callbackFlow
        }

        isGenerating = true

        val sink: (String, Boolean) -> Unit = { partialResult, done ->
            if (isGenerating) {
                if (partialResult.isNotEmpty()) {
                    trySend(partialResult)
                }

                if (done) {
                    isGenerating = false
                    close()
                }
            }
        }

        resultSink = sink

        try {
            // In MediaPipe tasks-genai 0.10.14 the async method accepts only
            // the prompt. Partial results are delivered by ResultListener above.
            engine.generateResponseAsync(prompt)
        } catch (t: Throwable) {
            isGenerating = false
            if (resultSink === sink) resultSink = null
            close(t)
        }

        awaitClose {
            if (resultSink === sink) resultSink = null
            isGenerating = false
        }
    }

    override fun stopGeneration() {
        // tasks-genai 0.10.14's stateless API does not expose cancellation
        // directly. Stop forwarding further partial results to the UI.
        isGenerating = false
    }
}
